
<svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="20" height="28" viewBox="0 0 5 7">
    <path fill="currentColor" fill-rule="evenodd" d="M3.936 2.944a.53.53 0 0 0-.723-.194L.463 4.338a.53.53 0 0 0-.193.723l.794 1.375a.53.53 0 0 0 .723.193l2.75-1.587a.53.53 0 0 0 .193-.723z" clip-rule="evenodd"/>
    <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width=".529" d="M4.22.564v1.044h-.126M.78 2.026C1.002.317 3.427.011 4.094 1.608m0 0h-.953"/>
</svg>
<?php /**PATH C:\Users\DELL\Desktop\projects\newtrips\vendor\pboivin\filament-peek\src\/../resources/views/partials/icon-rotate.blade.php ENDPATH**/ ?>