<?php foreach ((['page']) as $__key => $__value) {
    $__consumeVariable = is_string($__key) ? $__key : $__value;
    $$__consumeVariable = is_string($__key) ? $__env->getConsumableComponentData($__key, $__value) : $__env->getConsumableComponentData($__value);
} ?>

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title',
    'description',
    'block',
    'buttons',
    'backgrounds',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title',
    'description',
    'block',
    'buttons',
    'backgrounds',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>


<?php
    $totalImages = count($backgrounds);
    $currentHour = now()->hour; // Get current hour (0-23)
    
    // Determine whether it's the first 12-hour period or the second
    $isFirstPeriod = $currentHour < 12;
    $periodStart = $isFirstPeriod ? 0 : 12; // 0-11 or 12-23

    // Assign an image based on the time slot
    $slotDuration = 12 / $totalImages; // How long each image should be shown
    $imageIndex = floor(($currentHour - $periodStart) / $slotDuration);
    $selectedImage = $backgrounds[$imageIndex]['image'] ?? $backgrounds[0]['image']; // Fallback to the first image
?>

<!-- Hero Start -->
<section id="<?php echo e($block); ?>" class="relative py-36  bg-cover jarallax " data-jarallax data-speed="0.5" style="background-image: url('<?php echo e(asset('storage/'.$backgrounds[0]['image'])); ?>')">
    <div class="absolute inset-0 bg-slate-900/40"></div>
    <div class="container relative">
        <div class="grid lg:grid-cols-12 md:grid-cols-2 mt-10 items-center gap-6">
            <div class="lg:col-span-7">
                <h5 class="text-3xl font-dancing text-white">Find Your Ideal Stay</h5>
                <h4 class="font-bold text-white lg:leading-normal leading-normal text-4xl lg:text-6xl mb-6 mt-5">
                <?php echo e($title); ?>   
                </h4>
                <p class="text-white/70 text-xl max-w-xl"><?php echo e($description); ?></p>

                <div class="mt-6">
                   <?php $__currentLoopData = $buttons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $button): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     <?php if($button['type'] === 'text'): ?>
                         <a href="<?php echo e($button['action']=='redirect' ? $button['url']:('#'.$button['url'])); ?>"
                         class="py-2 px-5 inline-block tracking-wide align-middle duration-500 text-base text-center bg-red-500 text-white rounded-md">
                            <?php echo e($button['button_text']); ?>

                         </a>
                     <?php endif; ?>
                     <?php if($button['type'] === 'icon'): ?>
                          <a href="<?php echo e($button['url']); ?>" 
                                class="size-10 inline-flex items-center justify-center tracking-wide align-middle duration-500 text-base text-center rounded-full border border-red-500 bg-red-500 text-white ms-1 lightbox">
                                  <?php echo e(svg($button['icon'], ['style' => 'width:20px','class' => 'ms-1'])); ?>
                          </a>
                     <?php endif; ?>
                     <?php if($button['type'] === 'icontext'): ?>
                         <a href="<?php echo e($button['url']); ?>"
                         class="py-2 px-5 inline-flex items-center tracking-wide align-middle duration-500 text-base text-center bg-red-500 text-white rounded-md"> 
                            <?php echo e($button['button_text']); ?>

                            <?php echo e(svg($button['icon'], ['style' => 'width:20px','class' => 'ms-1'])); ?>
                         </a>
                     <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="lg:col-span-5">
                <div
                    class="bg-white dark:bg-slate-900 rounded-xl shadow dark:shadow-gray-800 p-6 z-10 relative lg:ms-10">
                    <h4 class="mb-5 text-2xl font-semibold">Searchs Your Destinations</h4>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('destination-pages-form');

$__html = app('livewire')->mount($__name, $__params, 'lw-1660850965-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>
        </div><!--end grid-->
    </div><!--end container-->
</section><!--end section--><?php /**PATH C:\Users\DELL\Desktop\projects\newtrips\resources\views/components/filament-fabricator/page-blocks/hero1.blade.php ENDPATH**/ ?>