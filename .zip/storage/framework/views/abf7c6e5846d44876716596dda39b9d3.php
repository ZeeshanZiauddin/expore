<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>

<?php if (isset($component)) { $__componentOriginaled402dd632b3110e2c334b303925d7fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled402dd632b3110e2c334b303925d7fb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filament-fabricator.page-blocks.meta','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-fabricator.page-blocks.meta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled402dd632b3110e2c334b303925d7fb)): ?>
<?php $attributes = $__attributesOriginaled402dd632b3110e2c334b303925d7fb; ?>
<?php unset($__attributesOriginaled402dd632b3110e2c334b303925d7fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled402dd632b3110e2c334b303925d7fb)): ?>
<?php $component = $__componentOriginaled402dd632b3110e2c334b303925d7fb; ?>
<?php unset($__componentOriginaled402dd632b3110e2c334b303925d7fb); ?>
<?php endif; ?><?php /**PATH C:\Users\DELL\Desktop\projects\newtrips\storage\framework\views/34e7a3baa720f3862593c317b777151f.blade.php ENDPATH**/ ?>