<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title','backgrounds']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title','backgrounds']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginal1a8267bf98e836270224261890a0e75e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8267bf98e836270224261890a0e75e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filament-fabricator.page-blocks.hero2','data' => ['title' => $title,'backgrounds' => $backgrounds]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-fabricator.page-blocks.hero2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title),'backgrounds' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($backgrounds)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8267bf98e836270224261890a0e75e)): ?>
<?php $attributes = $__attributesOriginal1a8267bf98e836270224261890a0e75e; ?>
<?php unset($__attributesOriginal1a8267bf98e836270224261890a0e75e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8267bf98e836270224261890a0e75e)): ?>
<?php $component = $__componentOriginal1a8267bf98e836270224261890a0e75e; ?>
<?php unset($__componentOriginal1a8267bf98e836270224261890a0e75e); ?>
<?php endif; ?><?php /**PATH C:\Users\DELL\Desktop\projects\newtrips\storage\framework\views/bc1c48623141723dac4cdc815e7270cd.blade.php ENDPATH**/ ?>