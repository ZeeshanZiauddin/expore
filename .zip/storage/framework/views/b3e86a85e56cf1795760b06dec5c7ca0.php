
<!-- Start Navbar -->
<nav id="topnav" class="defaultscroll is-sticky tagline-height">
    <div class="container relative flex">
        <!-- Logo container-->
        <a class="logo" href="<?php echo e(route('home')); ?>">
            <span class="inline-block dark:hidden">
                <img src="<?php echo e(asset('assets/images/logo-dark.png')); ?>" class="h-16 l-dark" alt="">
                <img src="<?php echo e(asset('assets/images/logo-light.png')); ?>" class="h-16 l-light" alt="">
            </span>
            <img src="<?php echo e(asset('assets/images/logo-white.png')); ?>" class="hidden dark:inline-block" alt="">
        </a>
        <!-- End Logo container-->

        <!-- Start Mobile Toggle -->
        <div class="menu-extras ms-auto">
            <div class="menu-item">
                <a class="navbar-toggle" id="isToggle" onclick="toggleMenu()">
                    <div class="lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </a>
            </div>
        </div>
        <!-- End Mobile Toggle -->

        
        <div id="navigation" class="w-full">
            <!-- Navigation Menu-->
            <ul class="navigation-menu justify-end nav-light">
                <li><a href="<?php echo e(route('home')); ?>" class="sub-menu-item">Home</a></li>
                <li><a href="<?php echo e(route('about')); ?>" class="sub-menu-item">About Us</a></li>
                <li><a href="<?php echo e(route('contact')); ?>" class="sub-menu-item">Contact Us</a></li>                
                <li><a href="<?php echo e(route('filamentblog.post.all')); ?>" class="sub-menu-item">Blogs</a></li>
            </ul><!--end navigation menu-->
        </div><!--end navigation-->
    </div><!--end container-->
</nav><!--end header-->
<!-- End Navbar --><?php /**PATH C:\Users\DELL\Desktop\projects\newtrips\resources\views/components/layouts/navbar.blade.php ENDPATH**/ ?>