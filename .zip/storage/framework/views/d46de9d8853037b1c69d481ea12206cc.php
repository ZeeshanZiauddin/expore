<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['tags','title','description','ogTitle','ogImage','ogDescription','keywords']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['tags','title','description','ogTitle','ogImage','ogDescription','keywords']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginaled402dd632b3110e2c334b303925d7fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled402dd632b3110e2c334b303925d7fb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filament-fabricator.page-blocks.meta','data' => ['tags' => $tags,'title' => $title,'description' => $description,'ogTitle' => $ogTitle,'ogImage' => $ogImage,'ogDescription' => $ogDescription,'keywords' => $keywords]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-fabricator.page-blocks.meta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tags' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tags),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($description),'og_title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ogTitle),'og_image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ogImage),'og_description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ogDescription),'keywords' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($keywords)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled402dd632b3110e2c334b303925d7fb)): ?>
<?php $attributes = $__attributesOriginaled402dd632b3110e2c334b303925d7fb; ?>
<?php unset($__attributesOriginaled402dd632b3110e2c334b303925d7fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled402dd632b3110e2c334b303925d7fb)): ?>
<?php $component = $__componentOriginaled402dd632b3110e2c334b303925d7fb; ?>
<?php unset($__componentOriginaled402dd632b3110e2c334b303925d7fb); ?>
<?php endif; ?><?php /**PATH C:\Users\DELL\Desktop\projects\newtrips\storage\framework\views/9aeba714eea468a11a1454673697dae4.blade.php ENDPATH**/ ?>