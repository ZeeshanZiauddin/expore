<?php foreach ((['page']) as $__key => $__value) {
    $__consumeVariable = is_string($__key) ? $__key : $__value;
    $$__consumeVariable = is_string($__key) ? $__env->getConsumableComponentData($__key, $__value) : $__env->getConsumableComponentData($__value);
} ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title',
    'backgrounds'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title',
    'backgrounds'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>


<?php
    $totalImages = count($backgrounds);
    $currentHour = now()->hour; // Get current hour (0-23)
    
    // Determine whether it's the first 12-hour period or the second
    $isFirstPeriod = $currentHour < 12;
    $periodStart = $isFirstPeriod ? 0 : 12; // 0-11 or 12-23

    // Assign an image based on the time slot
    $slotDuration = 12 / $totalImages; // How long each image should be shown
    $imageIndex = floor(($currentHour - $periodStart) / $slotDuration);
    $selectedImage = $backgrounds[$imageIndex]['image'] ?? $backgrounds[0]['image']; // Fallback to the first image
?>

<style>
    .container-padding{
     padding-top: 9rem;
     padding-bottom: 2rem;
    }
    .hero-heading{
     font-size: 4rem;
     font-weight: 900;
    }
</style>

<section
    class="relative table w-full items-center container-padding bg-top bg-no-repeat bg-cover" style="background-image: url('<?php echo e(asset('storage/'.$backgrounds[0]['image'])); ?>')">
    <div class="absolute inset-0 bg-gradient-to-b from-slate-900/60 via-slate-900/80 to-slate-900"></div>
    <div class="container relative">
        <div class="grid grid-cols-1 pb-2  mt-4 ">
            <h3 class="hero-heading  text-white pb-4"><?php echo e($title); ?></h3>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('main-form');

$__html = app('livewire')->mount($__name, $__params, 'lw-4212978964-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div><!--end grid-->
    </div><!--end container-->
</section><!--end section-->
<!-- End Hero --><?php /**PATH C:\Users\DELL\Desktop\projects\newtrips\resources\views/components/filament-fabricator/page-blocks/hero2.blade.php ENDPATH**/ ?>