<x-dynamic-component
    :component="$component"
    :page="$page"
/>