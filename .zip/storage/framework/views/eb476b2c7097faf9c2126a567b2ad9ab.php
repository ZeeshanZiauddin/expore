

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<?php if (! empty(trim($__env->yieldContent('title')))): ?>
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e($meta['title'] ?? config('app.name')); ?></title>
<?php else: ?>
    <title><?php echo e($meta['title'] ?? config('app.name')); ?></title>
<?php endif; ?>
<meta content="Tour & Travels Agency Tailwind CSS Template" name="description">
<meta
    content="Tour, Travels, agency, business, corporate, tour packages, journey, trip, tailwind css, Admin, Landing"
    name="keywords">
<meta name="author" content="@ZeeshanZiauddin">

<meta name="email" content="zeeshanziauddin6@gmail.com">

<!-- favicon -->
<link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">

<!-- Css -->
<link href="<?php echo e(asset('assets/libs/tobii/css/tobii.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/libs/tiny-slider/tiny-slider.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/libs/js-datepicker/datepicker.min.css')); ?>" rel="stylesheet">
<!-- Main Css -->
<link href="<?php echo e(asset("assets/libs/@mdi/font/css/materialdesignicons.min.css")); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/tailwind.css')); ?>" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="https://rsms.me/inter/inter.css">

<?php /**PATH C:\Users\DELL\Desktop\projects\newtrips\resources\views/components/layouts/head-tags.blade.php ENDPATH**/ ?>