<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
@props(['tags','title','description','ogTitle','ogImage','ogDescription','keywords'])
<x-filament-fabricator.page-blocks.meta :tags="$tags" :title="$title" :description="$description" :og_title="$ogTitle" :og_image="$ogImage" :og_description="$ogDescription" :keywords="$keywords" >

{{ $slot ?? "" }}
</x-filament-fabricator.page-blocks.meta>