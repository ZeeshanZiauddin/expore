<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
@props(['keywords','title','description','ogTitle','ogImage','ogDescription'])
<x-filament-fabricator.page-blocks.meta :keywords="$keywords" :title="$title" :description="$description" :og_title="$ogTitle" :og_image="$ogImage" :og_description="$ogDescription" >

{{ $slot ?? "" }}
</x-filament-fabricator.page-blocks.meta>