<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
@props(['cover','backgrounds','faqs'])
<x-filament-fabricator.page-blocks.f-a-q :cover="$cover" :backgrounds="$backgrounds" :faqs="$faqs" >

{{ $slot ?? "" }}
</x-filament-fabricator.page-blocks.f-a-q>