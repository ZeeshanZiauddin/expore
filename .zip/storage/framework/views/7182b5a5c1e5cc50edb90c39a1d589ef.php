
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="language" content="en-UK">

<title><?php echo $__env->yieldContent('meta-title', 'Explore Flights'); ?></title>

<meta content="<?php echo $__env->yieldContent('meta-description', 'default'); ?>" name="description">
<meta name="keywords"
    content="<?php echo $__env->yieldContent('meta-keywords', 'Tour, Travels, agency, business, corporate, tour packages, journey, trip'); ?>">
<link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">


<meta name="author" content="@ZeeshanZiauddin">
<meta name="robots" content="<?php echo $__env->yieldContent('meta_robots', 'noindex, nofollow'); ?>">

<meta name="theme-color" content="#ff6900">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">

<meta http-equiv="X-Frame-Options" content="DENY">


<meta property="og:title" content="<?php echo $__env->yieldContent('meta-og-title', 'Find cheapest Flights'); ?>">
<meta property="og:description" content="<?php echo $__env->yieldContent('meta-og-description', 'Find cheapest Flights'); ?>">
<meta property="og:image" content="<?php echo $__env->yieldContent('meta-og-image', 'https://yourwebsite.com/og-image.jpg'); ?>">
<meta property="og:url" content="<?php echo e(asset('')); ?>">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Explore Flights">

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Your Page Title">
<meta name="twitter:description" content="A compelling description for Twitter.">
<meta name="twitter:image" content="https://yourwebsite.com/twitter-image.jpg">
<meta name="twitter:site" content="@YourTwitterHandle">
<link rel="canonical" href="<?php echo $__env->yieldContent('canonical', request()->url()); ?>">

<!-- Css -->
<link href="<?php echo e(asset('assets/libs/tobii/css/tobii.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/libs/tiny-slider/tiny-slider.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/libs/js-datepicker/datepicker.min.css')); ?>" rel="stylesheet">

<!-- Main Css -->
<link href="<?php echo e(asset(" assets/libs/@mdi/font/css/materialdesignicons.min.css")); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/tailwind.css')); ?>" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="https://rsms.me/inter/inter.css"><?php /**PATH C:\Users\DELL\Desktop\projects\newtrips\resources\views/components/layouts/fabricator-meta.blade.php ENDPATH**/ ?>