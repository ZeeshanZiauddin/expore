<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>
        
        <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>
        <?php echo \Filament\Support\Facades\FilamentAsset::renderScripts() ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

        <?php echo $__env->make('components.layouts.head-tags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>

<body class="antialiased relative">

    
    <?php echo $__env->yieldContent('body'); ?>



    <!-- JAVASCRIPTS -->
    <?php echo $__env->make('components.layouts.foot-tags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo \Filament\Support\Facades\FilamentAsset::renderScripts() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <!-- JAVASCRIPTS END-->

</body>

</html><?php /**PATH C:\Users\DELL\Desktop\projects\newtrips\resources\views/layouts/base.blade.php ENDPATH**/ ?>