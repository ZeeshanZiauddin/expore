<div style="padding:20px; border:1px solid #ddd; background:#f9f9f9;">
    {!! $html !!}
</div>
