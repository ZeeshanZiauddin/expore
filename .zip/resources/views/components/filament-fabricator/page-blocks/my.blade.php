@aware(['page'])
<div class="px-4 py-4 md:py-8">
    <div class="max-w-7xl mx-auto" style="height: 500px">
        <h1>My Block</h1>
    </div>
</div>