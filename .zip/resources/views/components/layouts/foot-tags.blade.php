<script src="{{asset('assets/libs/tobii/js/tobii.min.js')}}"></script>
<script src="{{asset('assets/libs/tiny-slider/min/tiny-slider.js')}}"></script>
<script src="{{asset('assets/libs/jarallax/jarallax.min.js')}}"></script>
<script src="{{asset('assets/js/easy_background.js')}}"></script>
<script src="{{asset('assets/libs/js-datepicker/datepicker.min.js')}}"></script>
<script src="{{asset('assets/libs/feather-icons/feather.min.js')}}"></script>
<script src="{{asset('assets/js/plugins.init.js')}}"></script>
<script src="{{asset('assets/js/app.js')}}"></script>
<script>
    easy_background("#home",
        {
            slide: ["assets/images/bg/4.jpg", "assets/images/bg/5.jpg", "assets/images/bg/6.jpg"],
            delay: [4000, 4000, 4000],
            
        }
    );
</script>