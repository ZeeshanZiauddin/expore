<?php return array (
  'anourvalar/eloquent-serialize' => 
  array (
    'aliases' => 
    array (
      'EloquentSerialize' => 'AnourValar\\EloquentSerialize\\Facades\\EloquentSerializeFacade',
    ),
  ),
  'awcodes/filament-curator' => 
  array (
    'providers' => 
    array (
      0 => 'Awcodes\\Curator\\CuratorServiceProvider',
    ),
  ),
  'awcodes/filament-tiptap-editor' => 
  array (
    'providers' => 
    array (
      0 => 'FilamentTiptapEditor\\FilamentTiptapEditorServiceProvider',
    ),
  ),
  'aymanalhattami/filament-slim-scrollbar' => 
  array (
    'aliases' => 
    array (
      'FilamentSlimScrollbar' => 'Aymanalhattami\\FilamentSlimScrollbar\\FilamentSlimScrollbarFacade',
    ),
    'providers' => 
    array (
      0 => 'Aymanalhattami\\FilamentSlimScrollbar\\FilamentSlimScrollbarServiceProvider',
    ),
  ),
  'bezhansalleh/filament-google-analytics' => 
  array (
    'aliases' => 
    array (
      'FilamentGoogleAnalytics' => 'BezhanSalleh\\FilamentGoogleAnalytics\\Facades\\FilamentGoogleAnalytics',
    ),
    'providers' => 
    array (
      0 => 'BezhanSalleh\\FilamentGoogleAnalytics\\FilamentGoogleAnalyticsServiceProvider',
    ),
  ),
  'bezhansalleh/filament-shield' => 
  array (
    'aliases' => 
    array (
      'FilamentShield' => 'BezhanSalleh\\FilamentShield\\Facades\\FilamentShield',
    ),
    'providers' => 
    array (
      0 => 'BezhanSalleh\\FilamentShield\\FilamentShieldServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-heroicons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Heroicons\\BladeHeroiconsServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-ui-kit' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUIKit\\BladeUIKitServiceProvider',
    ),
  ),
  'brunocfalcao/blade-feather-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Brunocfalcao\\BladeFeatherIcons\\BladeFeatherIconsServiceProvider',
    ),
  ),
  'filament/actions' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Actions\\ActionsServiceProvider',
    ),
  ),
  'filament/filament' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\FilamentServiceProvider',
    ),
  ),
  'filament/forms' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Forms\\FormsServiceProvider',
    ),
  ),
  'filament/infolists' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Infolists\\InfolistsServiceProvider',
    ),
  ),
  'filament/notifications' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Notifications\\NotificationsServiceProvider',
    ),
  ),
  'filament/spatie-laravel-settings-plugin' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\SpatieLaravelSettingsPluginServiceProvider',
    ),
  ),
  'filament/support' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Support\\SupportServiceProvider',
    ),
  ),
  'filament/tables' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Tables\\TablesServiceProvider',
    ),
  ),
  'filament/widgets' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Widgets\\WidgetsServiceProvider',
    ),
  ),
  'firefly/filament-blog' => 
  array (
    'providers' => 
    array (
      0 => 'Firefly\\FilamentBlog\\FilamentBlogServiceProvider',
    ),
  ),
  'genealabs/laravel-model-caching' => 
  array (
    'providers' => 
    array (
      0 => 'GeneaLabs\\LaravelModelCaching\\Providers\\Service',
    ),
  ),
  'intervention/image' => 
  array (
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
  ),
  'jenssegers/agent' => 
  array (
    'aliases' => 
    array (
      'Agent' => 'Jenssegers\\Agent\\Facades\\Agent',
    ),
    'providers' => 
    array (
      0 => 'Jenssegers\\Agent\\AgentServiceProvider',
    ),
  ),
  'joaopaulolndev/filament-edit-profile' => 
  array (
    'aliases' => 
    array (
      'FilamentEditProfile' => 'Joaopaulolndev\\FilamentEditProfile\\Facades\\FilamentEditProfile',
    ),
    'providers' => 
    array (
      0 => 'Joaopaulolndev\\FilamentEditProfile\\FilamentEditProfileServiceProvider',
    ),
  ),
  'joshembling/image-optimizer' => 
  array (
    'aliases' => 
    array (
      'ImageOptimizer' => 'Joshembling\\ImageOptimizer\\Facades\\ImageOptimizer',
    ),
    'providers' => 
    array (
      0 => 'Joshembling\\ImageOptimizer\\ImageOptimizerServiceProvider',
    ),
  ),
  'kirschbaum-development/eloquent-power-joins' => 
  array (
    'providers' => 
    array (
      0 => 'Kirschbaum\\PowerJoins\\PowerJoinsServiceProvider',
    ),
  ),
  'laravel/pail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Pail\\PailServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'livewire/livewire' => 
  array (
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'pboivin/filament-peek' => 
  array (
    'providers' => 
    array (
      0 => 'Pboivin\\FilamentPeek\\FilamentPeekServiceProvider',
    ),
  ),
  'pestphp/pest-plugin-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Pest\\Laravel\\PestServiceProvider',
    ),
  ),
  'propaganistas/laravel-phone' => 
  array (
    'providers' => 
    array (
      0 => 'Propaganistas\\LaravelPhone\\PhoneServiceProvider',
    ),
  ),
  'ryangjchandler/blade-capture-directive' => 
  array (
    'aliases' => 
    array (
      'BladeCaptureDirective' => 'RyanChandler\\BladeCaptureDirective\\Facades\\BladeCaptureDirective',
    ),
    'providers' => 
    array (
      0 => 'RyanChandler\\BladeCaptureDirective\\BladeCaptureDirectiveServiceProvider',
    ),
  ),
  'spatie/laravel-analytics' => 
  array (
    'aliases' => 
    array (
      'Analytics' => 'Spatie\\Analytics\\Facades\\Analytics',
    ),
    'providers' => 
    array (
      0 => 'Spatie\\Analytics\\AnalyticsServiceProvider',
    ),
  ),
  'spatie/laravel-medialibrary' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\MediaLibrary\\MediaLibraryServiceProvider',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'spatie/laravel-settings' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelSettings\\LaravelSettingsServiceProvider',
    ),
  ),
  'spatie/laravel-sitemap' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Sitemap\\SitemapServiceProvider',
    ),
  ),
  'tomatophp/console-helpers' => 
  array (
    'providers' => 
    array (
      0 => 'TomatoPHP\\ConsoleHelpers\\ConsoleHelpersServiceProvider',
    ),
  ),
  'tomatophp/filament-icons' => 
  array (
    'providers' => 
    array (
      0 => 'TomatoPHP\\FilamentIcons\\FilamentIconsServiceProvider',
    ),
  ),
  'tomatophp/filament-pwa' => 
  array (
    'providers' => 
    array (
      0 => 'TomatoPHP\\FilamentPWA\\FilamentPwaServiceProvider',
    ),
  ),
  'tomatophp/filament-settings-hub' => 
  array (
    'providers' => 
    array (
      0 => 'TomatoPHP\\FilamentSettingsHub\\FilamentSettingsHubServiceProvider',
    ),
  ),
  'tomatophp/filament-twilio' => 
  array (
    'providers' => 
    array (
      0 => 'TomatoPHP\\FilamentTwilio\\FilamentTwilioServiceProvider',
    ),
  ),
  'ysfkaya/filament-phone-input' => 
  array (
    'providers' => 
    array (
      0 => 'Ysfkaya\\FilamentPhoneInput\\FilamentPhoneInputServiceProvider',
    ),
  ),
  'z3d0x/filament-fabricator' => 
  array (
    'aliases' => 
    array (
      'FilamentFabricator' => 'Z3d0X\\FilamentFabricator\\Facades\\FilamentFabricator',
    ),
    'providers' => 
    array (
      0 => 'Z3d0X\\FilamentFabricator\\FilamentFabricatorServiceProvider',
    ),
  ),
);